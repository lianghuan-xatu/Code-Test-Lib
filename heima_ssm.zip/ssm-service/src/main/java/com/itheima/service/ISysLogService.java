package com.itheima.service;

import com.itheima.domain.SysLog;

public interface ISysLogService {

    public void save(SysLog sysLog);
}
